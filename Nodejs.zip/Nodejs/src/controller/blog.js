let date = new Date()

const getList =(author, keyword)=>{
    //mock data with correct format
    return[
        {
            id:1,
            title:"Tittle 1",
            content:"Content 1",
            createTime:date.getTime(),
            author:"Hao Yang"
        },
        {
            id:2,
            title:"Tittle 2",
            content:"Content 2",
            createTime:date.getTime(),
            author:"Jayden"
        },
        {
            id:3,
            title:"Tittle 3",
            content:"Content 3",
            createTime:date.getTime(),
            author:"Jackson"
        }
    ]
}

const getDetail=(id)=>{
    // return mock data
  return {
    id:1,
    title:"Tittle 1",
    content:"Content 1",
    createTime:date.getTime(),
    author:"Hao Yang"
  }

}

const newBlog=(blogData ={})=>{   // mean if there are nothing return empty obj
    console.log('blogData', blogData)
    return{
        id:4 //
    }

}

module.exports={getList,getDetail ,newBlog}