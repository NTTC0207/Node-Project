const {getList, getDetail,newBlog} =require("../controller/blog")
const {SuccessModel ,ErrorModel} = require("../model/resModel")
const handleBlogRouter =(req,res)=>{

        const method = req.method;
        const id = req.query.id
   
        
        //get blog list 
        if(method === 'GET' && req.path === "/api/blog/list"){
            const author = req.query.author || ''  // if there are nothing return '' 
            const keyword = req.query.keyword || ''
            const listData = getList(author,keyword)
          
            return new SuccessModel(listData)
        }

        //get blog data
        if(method === "GET" && req.path ==="/api/blog/detail"){
          const data = getDetail(id)
          return new SuccessModel(data)
        }

        //create new blog
        if(method === "POST" && req.path ==="/api/blog/new"){
          const data = newBlog(req.body)
          return new SuccessModel(data)
        }

        //update new blog
        if(method === "POST" && req.path ==="/api/blog/update"){
            return {
                msg: "Update successfully"
            }
        }

        //delete new blog
        if(method === "POST" && req.path ==="/api/blog/new"){
            return {
                msg: "Delete successfully"
            }
        }

    }

module.exports = handleBlogRouter