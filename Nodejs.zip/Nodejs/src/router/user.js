const handleUserRouter =((req,res)=>{
   const method = req.method;
 
   //login
   if( method==="POST" && req.path === "/api/user/login" ){
    return{
        msg:"Login successfully"
    }
   }

})

module.exports = handleUserRouter