const handleBlogRouter = require("./src/router/blog")
const handleUserRouter = require("./src/router/user")
const querystring = require("querystring")

const serverHandle =((req,res)=>{
    res.setHeader('Content-type','application/json')
    
    //get path
    const url = req.url
    req.path = url.split('?')[0]

    //jie xi query 
    req.query = querystring.parse(url.split('?')[0])

    //blog router 
    const blogData = handleBlogRouter(req,res)
    if(blogData){
        res.end(
            JSON.stringify(blogData)
        )
        return
    }

    const userData = handleUserRouter(req,res)
    if(userData){
        res.end(
            JSON.stringify(userData)
        )
        return
    }
 
    // //if found nothing return 404
    res.writeHead(404, {"Content-type":"text/plain"})
    res.write("404 Not Found")
    res.end()
  

})

module.exports = serverHandle

//process.env.NODE_ENV

// const http = require('http');
// const querystring = require('querystring')

// const server = http.createServer((req,res)=>{ // GET Method
//    const method = req.method
//    const url = req.url
//    const path = url.split('?')[0]
//    const query= querystring.parse(url.split('?')[1])

//    //return json format
//    res.setHeader('Content-type','application/json') //text/html
//    //return data
//    const resData = {
//     method,
//     url,
//     path,
//     query
//    }

//    if(method === "GET"){
//     res.end(
//         JSON.stringify(resData)
//     )}

//     if(method === "POST"){
//         let PostData = ''
       
//         req.on('data', chuck=>{ //
//             PostData += chuck.toString();
//         })
//         req.on('end',()=>{
//             resData.PostData = PostData
//             res.end(
//                 JSON.stringify(resData)
//             )
//         })
//     }
 
// })

// const server = http.createServer((req,res)=>{
//     if(req.method === 'POST'){
//         console.log("req content type" , req.headers['content-type']); // use in post and put request
//         //get data from postman or fronted
//         let postData = ''
//         req.on('data' ,chuck =>{ // get chuck of data and add incrementally 
//           postData += chuck.toString();
//         })
//         req.on('end',()=>{
//             console.log('postData',postData)
//             res.end('hello world!')
//         })
//     }
// })





// server.listen(8000)